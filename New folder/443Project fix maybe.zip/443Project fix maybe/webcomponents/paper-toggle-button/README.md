paper-toggle-button
===================

See the [component page](http://www.polymer-project.org/docs/elements/paper-elements.html#paper-toggle-button) for more information.
