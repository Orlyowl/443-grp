core-header-panel
===================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-header-panel) for more information.
