# *DEPRECATED*
> Please use [core-label](https://github.com/Polymer/core-label) instead

core-field
==========

See the [component landing page](http://polymer-project.org/docs/elements/core-elements.html#core-field) for more information.
